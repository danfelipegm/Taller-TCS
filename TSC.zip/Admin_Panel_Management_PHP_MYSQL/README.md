Admin_Panel_Management_PHP_MYSQL
User Login and Registration features: 
User registration with email User Login with remember password(SHA1()
. Change password
. User profile
. User profile edit &amp; save
. Admin Panel features:  Admin login
. Admin password Chane password. Admin profile
. Dashboard View Users list. Add new user with role
. Edit &amp; save user
. Delete user.
  
  
How to Install
Create a database name (db_admin)
Import database file (db_admin.sql)
Admin:Info
Admin username: achref.nefzazoui@gmail.com
Admin pass: Achref1
